"use strict";

var _cheerioMin = require("./cheerio.min.js");
var _mod = require("./mod.js");
var _sortName = require("./sortName.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
String.prototype.rstrip = function (chars) {
  var regex = new RegExp(chars + "$");
  return this.replace(regex, "");
};
var showMode = "single";
var searchDriver = "";
var limit_search_show = 200;
var search_type = "";
var authorization = "";
var detail_order = "name";
var request_timeout = 5e3;
var VERSION = "alist v2/v3 20221204";
var SELECT_REGEX = /:eq|:lt|:gt|#/g;
var SELECT_REGEX_A = /:eq|:lt|:gt/g;
function print(any) {
  any = any || "";
  if (_typeof(any) == "object" && Object.keys(any).length > 0) {
    try {
      any = JSON.stringify(any);
      console.log(any);
    } catch (e) {
      console.log(_typeof(any) + ":" + any.length);
    }
  } else if (_typeof(any) == "object" && Object.keys(any).length < 1) {
    console.log("null object");
  } else {
    console.log(any);
  }
}
function pdfh(html, parse, base_url) {
  if (!parse || !parse.trim()) {
    return "";
  }
  var eleFind = _typeof(html) === "object";
  var option = undefined;
  if (eleFind && parse.startsWith("body&&")) {
    parse = parse.substr(6);
    if (parse.indexOf("&&") < 0) {
      option = parse.trim();
      parse = "*=*";
    }
  }
  if (parse.indexOf("&&") > -1) {
    var sp = parse.split("&&");
    option = sp[sp.length - 1];
    sp.splice(sp.length - 1);
    if (sp.length > 1) {
      for (var i in sp) {
        if (sp.hasOwnProperty(i)) {
          if (!SELECT_REGEX.test(sp[i])) {
            sp[i] = sp[i] + ":eq(0)";
          }
        }
      }
    } else {
      if (!SELECT_REGEX.test(sp[0])) {
        sp[0] = sp[0] + ":eq(0)";
      }
    }
    parse = sp.join(" ");
  }
  var result = "";
  var $ = eleFind ? html.rr : uh(html);
  var ret = eleFind ? parse === "*=*" || $(html.ele).is(parse) ? html.ele : $(html.ele).find(parse) : $(parse);
  if (option) {
    if (option === "Text") {
      result = $(ret).text();
    } else if (option === "Html") {
      result = $(ret).html();
    } else {
      result = $(ret).attr(option);
      if (/style/.test(option.toLowerCase()) && /url\(/.test(result)) {
        try {
          result = result.match(/url\((.*?)\)/)[1];
        } catch (e) {}
      }
    }
    if (result && base_url && DOM_CHECK_ATTR.test(option)) {
      if (/http/.test(result)) {
        result = result.substr(result.indexOf("http"));
      } else {
        result = urljoin(base_url, result);
      }
    }
  } else {
    result = $(ret).toString();
  }
  return result;
}

function pdfa(html, parse) {
  if (!parse || !parse.trim()) {
    print("!parse");
    return [];
  }
  var eleFind = _typeof(html) === "object";
  if (parse.indexOf("&&") > -1) {
    var sp = parse.split("&&");
    for (var i in sp) {
      if (sp.hasOwnProperty(i)) {
        if (!SELECT_REGEX_A.test(sp[i]) && i < sp.length - 1) {
          if (sp[i] !== "body") {
            sp[i] = sp[i] + ":first";
          }
        }
      }
    }
    parse = sp.join(" ");
  }
  var $ = eleFind ? html.rr : uh(html);
  var ret = eleFind ? $(html.ele).is(parse) ? html.ele : $(html.ele).find(parse) : $(parse);
  var result = [];
  if (ret) {
    ret.each(function (idx, ele) {
      result.push({
        rr: $,
        ele: ele
      });
    });
  }
  return result;
}

var http = function http(url) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (options.method === "POST" && options.data) {
    options.body = JSON.stringify(options.data);
    options.headers = Object.assign({
      "content-type": "application/json"
    }, options.headers);
    options.headers = Object.assign({
      'Authorization': authorization
    }, options.headers);
  }
  options.timeout = request_timeout;
  try {
    var res = req(url, options);
    res.json = function () {
      return res && res.content ? JSON.parse(res.content) : null;
    };
    res.text = function () {
      return res && res.content ? res.content : "";
    };
    return res;
  } catch (e) {
    return {
      json: function json() {
        return null;
      },
      text: function text() {
        return "";
      }
    };
  }
};
["get", "post"].forEach(function (method) {
  http[method] = function (url) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return http(url, Object.assign(options, {
      method: method.toUpperCase()
    }));
  };
});
var __drives = {};
function isMedia(file) {
  return /\.(dff|dsf|mp3|aac|wav|wma|cda|flac|m4a|mid|mka|mp2|mpa|mpc|ape|ofr|ogg|ra|wv|tta|ac3|dts|tak|webm|wmv|mpeg|mov|ram|swf|mp4|avi|rm|rmvb|flv|mpg|mkv|m3u8|ts|3gp|asf)$/.test(file.toLowerCase());
}
function get_drives_path(tid) {
  var index = tid.indexOf("$");
  var name = tid.substring(0, index);
  var path = tid.substring(index + 1);
  return {
    drives: get_drives(name),
    path: path
  };
}
function get_drives(name) {
  var _drives$name = __drives[name],
    settings = _drives$name.settings,
    api = _drives$name.api,
    server = _drives$name.server;
  if (settings.v3 == null) {
    settings.v3 = false;
    var data = http.get(server + "/api/public/settings").json().data;
    if (Array.isArray(data)) {
      var _data$find, _data$find2, _data$find3;
      settings.title = (_data$find = data.find(function (x) {
        return x.key === "title";
      })) === null || _data$find === void 0 ? void 0 : _data$find.value;
      settings.v3 = false;
      settings.version = (_data$find2 = data.find(function (x) {
        return x.key === "version";
      })) === null || _data$find2 === void 0 ? void 0 : _data$find2.value;
      settings.enableSearch = ((_data$find3 = data.find(function (x) {
        return x.key === "enable search";
      })) === null || _data$find3 === void 0 ? void 0 : _data$find3.value) === "true";
    } else {
      settings.title = data.title;
      settings.v3 = true;
      settings.version = data.version;
      settings.enableSearch = false;
    }
    api.path = settings.v3 ? "/api/fs/list" : "/api/public/path";
    api.file = settings.v3 ? "/api/fs/get" : "/api/public/path";
    api.search = settings.v3 ? "/api/public/search" : "/api/public/search";
  }
  return __drives[name];
}
function init(ext) {
  console.log("当前版本号:" + VERSION);
  var data;
  if (_typeof(ext) == "object") {
    data = ext;
    print("alist ext:object");
  } else if (typeof ext == "string") {
    if (ext.startsWith("http")) {
      var alist_data = ext.split(";");
      var alist_data_url = alist_data[0];
      limit_search_show = alist_data.length > 1 ? Number(alist_data[1]) || limit_search_show : limit_search_show;
      search_type = alist_data.length > 2 ? alist_data[2] : search_type;
      authorization = alist_data.length > 3 ? alist_data[3] : authorization;
      print(alist_data_url);
      data = http.get(alist_data_url).json();
    } else {
      print("alist ext:json string");
      data = JSON.parse(ext);
    }
  }
  var drives = [];
  if (Array.isArray(data) && data.length > 0 && data[0].hasOwnProperty("server") && data[0].hasOwnProperty("name")) {
    drives = data;
  } else if (!Array.isArray(data) && data.hasOwnProperty("drives") && Array.isArray(data.drives)) {
    drives = data.drives.filter(function (it) {
      return it.type && it.type === "alist" || !it.type;
    });
  }
  print(drives);
  searchDriver = (drives.find(function (x) {
    return x.search;
  }) || {}).name || "";
  if (!searchDriver && drives.length > 0) {
    searchDriver = drives[0].name;
  }
  print(searchDriver);
  drives.forEach(function (item) {
    var _path_param = [];
    if (item.params) {
      _path_param = Object.keys(item.params);
      _path_param.sort(function (a, b) {
        return a.length - b.length;
      });
    }
    __drives[item.name] = {
      name: item.name,
      server: item.server.endsWith("/") ? item.server.rstrip("/") : item.server,
      startPage: item.startPage || "/",
      showAll: item.showAll === true,
      search: !!item.search,
      params: item.params || {},
      _path_param: _path_param,
      settings: {},
      api: {},
      getParams: function getParams(path) {
        var key = this._path_param.find(function (x) {
          return path.startsWith(x);
        });
        return Object.assign({}, this.params[key], {
          path: path
        });
      },
      getPath: function getPath(path) {
        var res = http.post(this.server + this.api.path, {
          data: this.getParams(path)
        }).json();
        return this.settings.v3 ? res.data.content : res.data.files;
      },
      getFile: function getFile(path) {
        var raw_url = this.server + "/d" + path;
        raw_url = encodeURI(raw_url);
        return {
          raw_url: raw_url
        };
      },
      isFolder: function isFolder(data) {
        return data.type === 1;
      },
      isVideo: function isVideo(data) {
        return this.settings.v3 ? data.type === 2 || data.type === 0 || data.type === 3 : data.type === 3 || data.type === 0 || data.type === 4;
      },
      is_subt: function is_subt(data) {
        if (data.type === 1) {
          return false;
        }
        var ext = /\.(srt|ass|scc|stl|ttml)$/;
        return ext.test(data.name);
      },
      getPic: function getPic(data) {
        var pic = this.settings.v3 ? data.thumb : data.thumbnail;
        return pic || (this.isFolder(data) ? "http://img1.3png.com/281e284a670865a71d91515866552b5f172b.png" : "");
      },
      getTime: function getTime(data, isStandard) {
        isStandard = isStandard || false;
        try {
          var tTime = data.updated_at || data.time_str || data.modified || "";
          var date = "";
          if (tTime) {
            tTime = tTime.split("T");
            date = tTime[0];
            if (isStandard) {
              date = date.replace(/-/g, "/");
            }
            tTime = tTime[1].split(/Z|\./);
            date += " " + tTime[0];
          }
          return date;
        } catch (e) {
          return "";
        }
      }
    };
  });
  print("init执行完毕");
}
function home(filter) {
  var classes = Object.keys(__drives).map(function (key) {
    return {
      type_id: "".concat(key, "$").concat(__drives[key].startPage),
      type_name: key,
      type_flag: "1"
    };
  });
  var filter_dict = {};
  var filters = [{
    key: "order",
    name: "排序",
    value: [{
      n: "名称⬆️",
      v: "vod_name_asc"
    }, {
      n: "名称⬇️",
      v: "vod_name_desc"
    }, {
      n: "中英⬆️",
      v: "vod_cn_asc"
    }, {
      n: "中英⬇️",
      v: "vod_cn_desc"
    }, {
      n: "时间⬆️",
      v: "vod_time_asc"
    }, {
      n: "时间⬇️",
      v: "vod_time_desc"
    }, {
      n: "大小⬆️",
      v: "vod_size_asc"
    }, {
      n: "大小⬇️",
      v: "vod_size_desc"
    }, {
      n: "无",
      v: "none"
    }]
  }, {
    key: "show",
    name: "播放展示",
    value: [{
      n: "单集",
      v: "single"
    }, {
      n: "全集",
      v: "all"
    }]
  }];
  classes.forEach(function (it) {
    filter_dict[it.type_id] = filters;
  });
  print("----home----");
  print(classes);
  return JSON.stringify({
    class: classes,
    filters: filter_dict
  });
}
function homeVod(params) {
  var driver = __drives[searchDriver];
  print(driver);
  var surl = driver.server + "/sou?filter=last&num=200&type=video";
  print("搜索链接:" + surl);
  var html = http.get(surl).text();
  var lists = [];
  try {
    lists = pdfa(html, "div&&ul&&a");
  } catch (e) {}
  print("\u641C\u7D22\u7ED3\u679C\u6570:".concat(lists.length, ",\u641C\u7D22\u7ED3\u679C\u663E\u793A\u6570\u91CF\u9650\u5236:").concat(limit_search_show));
  var vods = [];
  var excludeReg = /\.(pdf|epub|mobi|txt|doc|lrc)$/;
  var cnt = 0;
  lists.forEach(function (it) {
    var vhref = pdfh(it, "a&&href");
    if (vhref) {
      vhref = unescape(vhref);
    }
    if (excludeReg.test(vhref)) {
      return;
    }
    var parts = vhref.split('#');
    if (parts.length >= 2) {
      vhref = parts[0];
    }
    if (cnt < limit_search_show) {
      print(vhref);
    }
    cnt++;
    var vid = searchDriver + "$" + vhref + "#search#";
    if (showMode === "all") {
      vid += "#all#";
    }
    var have_pic = 0;
    var poster = '';
    var douban_rate = '';
    var display_path = '';
    if (parts.length === 5) {
      var uri_parts = parts[4].split('://');
      poster = driver.server + "/image/" + uri_parts[1];
      have_pic = 1;
    }
    if (parts.length >= 4) {
      douban_rate = parts[3];
    }
    if (parts.length < 2) {
      var path_list = parts[0].split('/');
      display_path = path_list[path_list.length - 2] + '/' + path_list[path_list.length - 1];
    }
    vods.push({
      //vod_name: pdfh(it, "a&&Text"),
      vod_id: vid,
      vod_name: parts.length < 2 ? display_path : parts[1],
//      vod_tag: isMedia(vhref) ? "file" : "folder",
      vod_tag: "file",
      vod_pic: have_pic ? poster : "http://img.xiaoya.pro/xiaoya.jpg",
      vod_remarks: douban_rate == '' ? "" : "豆瓣:" + douban_rate
    });
  });
  return JSON.stringify({
    list: vods
  });
}
function category(tid, pg, filter, extend) {
  var orid = tid.replace(/#all#|#search#/g, "");
  var _get_drives_path = get_drives_path(orid),
    drives = _get_drives_path.drives,
    path = _get_drives_path.path;
  var id = orid.endsWith("/") ? orid : orid + "/";
  var list = drives.getPath(path);
  var subList = [];
  var vodFiles = [];
  var allList = [];
  var fl = filter ? extend : {};
  if (fl.show) {
    showMode = fl.show;
  }
  list.forEach(function (item) {
    if (drives.is_subt(item)) {
      subList.push(item.name);
    }
    if (!drives.showAll && !drives.isFolder(item) && !drives.isVideo(item)) {
      return;
    }
    var vod_time = drives.getTime(item);
    var vod_size = get_size(item.size);
    var remark = vod_time.split(" ")[0].substr(3) + "\t" + vod_size;
    var vod_id = id + item.name + (drives.isFolder(item) ? "/" : "");
    if (showMode === "all") {
      vod_id += "#all#";
    }
    print(vod_id);
    var vod = {
      vod_id: vod_id,
      vod_name: item.name.replaceAll("$", "").replaceAll("#", ""),
      vod_pic: drives.getPic(item),
      vod_time: vod_time,
      vod_size: item.size,
      vod_tag: drives.isFolder(item) ? "folder" : "file",
      vod_remarks: drives.isFolder(item) ? remark + " 文件夹" : remark
    };
    if (drives.isVideo(item)) {
      vodFiles.push(vod);
    }
    allList.push(vod);
  });
  if (vodFiles.length === 1 && subList.length > 0) {
    var sub;
    if (subList.length === 1) {
      sub = subList[0];
    } else {
      var subs = JSON.parse(JSON.stringify(subList));
      subs.sort(function (a, b) {
        var a_similar = (a.includes("chs") ? 100 : 0) + levenshteinDistance(a, vodFiles[0].vod_name);
        var b_similar = (b.includes("chs") ? 100 : 0) + levenshteinDistance(b, vodFiles[0].vod_name);
        if (a_similar > b_similar) {
          return 1;
        } else {
          return -1;
        }
      });
      sub = subs.slice(-1)[0];
    }
    vodFiles[0].vod_id += "@@@" + sub;
    vodFiles[0].vod_remarks += "🏷️";
  } else {
    vodFiles.forEach(function (item) {
      var lh = 0;
      var sub;
      subList.forEach(function (s) {
        var l = levenshteinDistance(s, item.vod_name);
        if (l > 60 && l > lh) {
          sub = s;
          lh = l;
        }
      });
      if (sub) {
        item.vod_id += "@@@" + sub;
        item.vod_remarks += "🏷️";
      }
    });
  }
  if (fl.order) {
    var key = fl.order.split("_").slice(0, -1).join("_");
    var order = fl.order.split("_").slice(-1)[0];
    print("\u6392\u5E8Fkey:".concat(key, ",\u6392\u5E8Forder:").concat(order));
    if (key.includes("name")) {
      detail_order = "name";
      allList = sortListByName(allList, key, order);
    } else if (key.includes("cn")) {
      detail_order = "cn";
      allList = (0, _sortName.sortListByCN)(allList, "vod_name", order);
    } else if (key.includes("time")) {
      detail_order = "time";
      allList = sortListByTime(allList, key, order);
    } else if (key.includes("size")) {
      detail_order = "size";
      allList = sortListBySize(allList, key, order);
    } else if (fl.order.includes("none")) {
      detail_order = "none";
      print("不排序");
    }
  } else {
    if (detail_order !== "none") {
      allList = sortListByName(allList, "vod_name", "asc");
    }
  }
  if (pg && vodFiles.length > 1) {
    var vod = {
      vod_id: id + "~playlist",
      vod_name: "播放列表",
      vod_pic: "http://img1.3png.com/3063ad894f04619af7270df68a124f129c8f.png",
      vod_tag: "file",
      vod_remarks: "共" + vodFiles.length + "集"
    };
    allList.unshift(vod);
  }
  print("----category----" + "tid:".concat(tid, ",detail_order:").concat(detail_order, ",showMode:").concat(showMode));
  return JSON.stringify({
    page: 1,
    pagecount: 1,
    limit: allList.length,
    total: allList.length,
    list: allList
  });
}
function getAll(otid, tid, drives, path) {
  try {
    var content = category(tid, null, false, null);
    var isFile = isMedia(otid.replace(/#all#|#search#/g, "").split("@@@")[0]);
    var _JSON$parse = JSON.parse(content),
      list = _JSON$parse.list;
    var vod_play_url = [];
    list.forEach(function (x) {
      if (x.vod_tag === "file" && isMedia(x.vod_name)) {
        var vid = x.vod_id.replace(/#all#|#search#/g, "");
        vod_play_url.push("".concat(x.vod_name, "$").concat(vid.substring(vid.indexOf("$") + 1)));
      }
    });
    var pl = path.split("/").filter(function (it) {
      return it;
    });
    var vod_name = pl[pl.length - 1] || drives.name;
    if (vod_name === drives.name) {
      print(pl);
    }
//    if (otid.includes("#search#")) {
//      vod_name += "[搜]";
//    }
    var vod = {
      vod_id: otid,
      vod_name: vod_name,
      type_name: "文件夹",
      vod_pic: "",
      vod_content: tid,
      vod_tag: "folder",
      vod_play_from: drives.name,
      vod_play_url: vod_play_url.join("#"),
      vod_remarks: drives.settings.title
    };
    print("----detail1----");
    print(vod);
    return JSON.stringify({
      list: [vod]
    });
  } catch (e) {
    print(e.message);
    return JSON.stringify({
      list: [{}]
    });
  }
}
function playlist(otid, tid, drives, path) {
  tid = tid.replace('/~playlist', '');
  otid = otid.replace('/~playlist', '');
  path = path.replace('/~playlist', '');
  return getAll(otid, tid, drives, path);
}
function detail(tid) {
  var isSearch = tid.includes("#search#");
  var isAll = tid.includes("#all#");
  var otid = tid;
  tid = tid.replace(/#all#|#search#/g, "");
  var isFile = isMedia(tid.split("@@@")[0]);
  print("isFile:".concat(tid, "?").concat(isFile));
  var _get_drives_path2 = get_drives_path(tid),
    drives = _get_drives_path2.drives,
    path = _get_drives_path2.path;
  print("drives:".concat(drives, ",path:").concat(path));
  if (path.endsWith("/")) {
    return getAll(otid, tid, drives, path);
  } else if (path.endsWith("/~playlist")) {
    return playlist(otid, tid, drives, path);
  } else {
    if (isSearch && !isFile) {
      return getAll(otid, tid, drives, path);
    } else if (isAll) {
      var new_tid;
      if (isFile) {
        new_tid = tid.split("/").slice(0, -1).join("/") + "/";
      } else {
        new_tid = tid;
      }
      print("\u5168\u96C6\u6A21\u5F0F tid:".concat(tid, "=>tid:").concat(new_tid));
      var _get_drives_path3 = get_drives_path(new_tid),
        _drives = _get_drives_path3.drives,
        _path = _get_drives_path3.path;
      return getAll(otid, new_tid, _drives, _path);
    } else if (isFile) {
      var paths = path.split("@@@");
      var vod_name = paths[0].substring(paths[0].lastIndexOf("/") + 1);
      var vod_title = vod_name;
//      if (otid.includes("#search#")) {
//        vod_title += "[搜]";
//      }
      var vod = {
        vod_id: otid,
        vod_name: vod_title,
        type_name: "文件",
        vod_pic: "",
        vod_content: tid,
        vod_play_from: drives.name,
        vod_play_url: vod_name + "$" + path,
        vod_remarks: drives.settings.title
      };
      print("----detail2----");
      print(vod);
      return JSON.stringify({
        list: [vod]
      });
    } else {
      return JSON.stringify({
        list: []
      });
    }
  }
}
function play(flag, id, flags) {
  var drives = get_drives(flag);
  var urls = id.split("@@@");
  var vod = {
    parse: 0,
    playUrl: "",
    url: drives.getFile(urls[0]).raw_url
  };
  if (urls.length >= 2) {
    var path = urls[0].substring(0, urls[0].lastIndexOf("/") + 1);
    vod.subt = drives.getFile(path + urls[1]).raw_url;
  }
  print("----play----");
  print(vod);
  return JSON.stringify(vod);
}
function search(wd, quick) {
  print(__drives);
  print("可搜索的alist驱动:" + searchDriver);
  if (!searchDriver || !wd) {
    return JSON.stringify({
      list: []
    });
  } else {
    var driver = __drives[searchDriver];
    wd = wd.split(" ").filter(function (it) {
      return it.trim();
    }).join("+");
    print(driver);
    var surl = driver.server + "/sou?box=" + wd + "&url=";
    if (search_type) {
      surl += "&type=" + search_type;
    }
    print("搜索链接:" + surl);
    var html = http.get(surl).text();
    var lists = [];
    try {
      lists = pdfa(html, "div&&ul&&a");
    } catch (e) {}
    print("\u641C\u7D22\u7ED3\u679C\u6570:".concat(lists.length, ",\u641C\u7D22\u7ED3\u679C\u663E\u793A\u6570\u91CF\u9650\u5236:").concat(limit_search_show));
    var vods = [];
    var excludeReg = /\.(pdf|epub|mobi|txt|doc|lrc)$/;
    var cnt = 0;
    lists.forEach(function (it) {
      var vhref = pdfh(it, "a&&href");
      if (vhref) {
        vhref = unescape(vhref);
      }
      if (excludeReg.test(vhref)) {
        return;
      }
      var parts = vhref.split('#');
      if (parts.length >= 2) {
        vhref = parts[0];
      }
      if (cnt < limit_search_show) {
        print(vhref);
      }
      cnt++;
      var vid = searchDriver + "$" + vhref + "#search#";
      if (showMode === "all") {
        vid += "#all#";
      }
      var have_pic = 0;
      var poster = '';
      var douban_rate = '';
      var display_path = '';
      if (parts.length === 5) {
        var uri_parts = parts[4].split('://');
        poster = driver.server + "/image/" + uri_parts[1];
        have_pic = 1;
      }
      if (parts.length >= 4) {
        douban_rate = parts[3];
      }
      if (parts.length < 2) {
        var path_list = parts[0].split('/');
        display_path = path_list[path_list.length - 2] + '/' + path_list[path_list.length - 1];
      }
      vods.push({
        //vod_name: pdfh(it, "a&&Text"),
        vod_id: vid,
        vod_name: parts.length < 2 ? display_path : parts[1],
        vod_tag: isMedia(vhref) ? "file" : "folder",
        vod_pic: have_pic ? poster : "http://img.xiaoya.pro/xiaoya.jpg",
        vod_remarks: douban_rate == '' ? searchDriver : searchDriver + " /豆瓣:" + douban_rate
      });
    });
    vods = vods.slice(0, limit_search_show);
    print(vods);
    return JSON.stringify({
      list: vods
    });
  }
}
function get_size(sz) {
  if (sz <= 0) {
    return "";
  }
  var filesize = "";
  if (sz > 1024 * 1024 * 1024 * 1024) {
    sz /= 1024 * 1024 * 1024 * 1024;
    filesize = "TB";
  } else if (sz > 1024 * 1024 * 1024) {
    sz /= 1024 * 1024 * 1024;
    filesize = "GB";
  } else if (sz > 1024 * 1024) {
    sz /= 1024 * 1024;
    filesize = "MB";
  } else if (sz > 1024) {
    sz /= 1024;
    filesize = "KB";
  } else {
    filesize = "B";
  }
  var sizeStr = sz.toFixed(2) + filesize,
    index = sizeStr.indexOf("."),
    dou = sizeStr.substr(index + 1, 2);
  if (dou === "00") {
    return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
  } else {
    return sizeStr;
  }
}
function levenshteinDistance(str1, str2) {
  return 100 - 100 * (0, distance)(str1, str2) / Math.max(str1.length, str2.length);
}
function naturalSort(options) {
  if (!options) {
    options = {};
  }
  return function (a, b) {
    if (options.key) {
      a = a[options.key];
      b = b[options.key];
    }
    var EQUAL = 0;
    var GREATER = options.order === "desc" ? -1 : 1;
    var SMALLER = -GREATER;
    var re = /(^-?[0-9]+(\.?[0-9]*)[df]?e?[0-9]?$|^0x[0-9a-f]+$|[0-9]+)/gi;
    var sre = /(^[ ]*|[ ]*$)/g;
    var dre = /(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[\/\-]\d{1,4}[\/\-]\d{1,4}|^\w+, \w+ \d+, \d{4})/;
    var hre = /^0x[0-9a-f]+$/i;
    var ore = /^0/;
    var normalize = function normalize(value) {
      var string = "" + value;
      return options.caseSensitive ? string : string.toLowerCase();
    };
    var x = normalize(a).replace(sre, "") || "";
    var y = normalize(b).replace(sre, "") || "";
    var xN = x.replace(re, "\0$1\0").replace(/\0$/, "").replace(/^\0/, "").split("\0");
    var yN = y.replace(re, "\0$1\0").replace(/\0$/, "").replace(/^\0/, "").split("\0");
    if (!x && !y) return EQUAL;
    if (!x && y) return GREATER;
    if (x && !y) return SMALLER;
    var xD = parseInt(x.match(hre)) || xN.length != 1 && x.match(dre) && Date.parse(x);
    var yD = parseInt(y.match(hre)) || xD && y.match(dre) && Date.parse(y) || null;
    var oFxNcL, oFyNcL;
    if (yD) {
      if (xD < yD) return SMALLER;else if (xD > yD) return GREATER;
    }
    for (var cLoc = 0, numS = Math.max(xN.length, yN.length); cLoc < numS; cLoc++) {
      oFxNcL = !(xN[cLoc] || "").match(ore) && parseFloat(xN[cLoc]) || xN[cLoc] || 0;
      oFyNcL = !(yN[cLoc] || "").match(ore) && parseFloat(yN[cLoc]) || yN[cLoc] || 0;
      if (isNaN(oFxNcL) !== isNaN(oFyNcL)) return isNaN(oFxNcL) ? GREATER : SMALLER;else if (_typeof(oFxNcL) !== _typeof(oFyNcL)) {
        oFxNcL += "";
        oFyNcL += "";
      }
      if (oFxNcL < oFyNcL) return SMALLER;
      if (oFxNcL > oFyNcL) return GREATER;
    }
    return EQUAL;
  };
}
var sortListByName = function sortListByName(vodList, key, order) {
  if (!key) {
    return vodList;
  }
  order = order || "asc";
  return vodList.sort(naturalSort({
    key: key,
    order: order,
    caseSensitive: true
  }));
};
var getTimeInt = function getTimeInt(timeStr) {
  return new Date(timeStr).getTime();
};
var sortListByTime = function sortListByTime(vodList, key, order) {
  if (!key) {
    return vodList;
  }
  var ASCarr = vodList.sort(function (a, b) {
    a = a[key];
    b = b[key];
    return getTimeInt(a) - getTimeInt(b);
  });
  if (order === "desc") {
    ASCarr.reverse();
  }
  return ASCarr;
};
var sortListBySize = function sortListBySize(vodList, key, order) {
  if (!key) {
    return vodList;
  }
  var ASCarr = vodList.sort(function (a, b) {
    a = a[key];
    b = b[key];
    return (Number(a) || 0) - (Number(b) || 0);
  });
  if (order === "desc") {
    ASCarr.reverse();
  }
  return ASCarr;
};
