"use strict";

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }
function _readOnlyError(name) { throw new TypeError("\"" + name + "\" is read-only"); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

var host = '';
var header = {
  'User-Agent': 'okhttp/3.12.11'
};
var siteKey = '';
var siteType = '';
var siteJx = '';
var urlPattern1 = /api\.php\/.*?\/vod/;
var urlPattern2 = /api\.php\/.+?\.vod/;
var parsePattern = /\/.+\\?.+=/;
var parsePattern1 = /.*(url|v|vid|php\?id)=/;
var parsePattern2 = /https?:\/\/[^\/]*/;
var htmlVideoKeyMatch = [/player=new/, /<div id="video"/, /<div id="[^"]*?player"/, /\/\/视频链接/, /HlsJsPlayer\(/, /<iframe[\s\S]*?src="[^"]+?"/, /<video[\s\S]*?src="[^"]+?"/];
function init(ext) {
  host = ext;
};
function request(reqUrl, referer, mth, data, hd) {
    var headers = {
        "User-Agent": UA
    };
    var res = req(reqUrl, {method: mth || "get",headers: headers,data: data,
    postType: "post" === mth ? "form" : ""
    });
    return res && res.content ? res.content : "";
}
function home(filter) {
  try {
    var url = getCateUrl(host);
    var jsonArray = null;
    if (url) {
      var json = request(url, getHeaders(url));
      var obj = JSON.parse(json);
      if (obj.hasOwnProperty("list") && Array.isArray(obj.list)) {
        jsonArray = obj.list;
      } else if (obj.hasOwnProperty("data") && obj.data.hasOwnProperty("list") && Array.isArray(obj.data.list)) {
        jsonArray = obj.data.list;
      } else if (obj.hasOwnProperty("data") && Array.isArray(obj.data)) {
        jsonArray = obj.data;
      }
    } else {
      // 通过filter列表读分类
      var filterStr = getFilterTypes(url, null);
      var classes = filterStr.split("\n")[0].split("+");
      jsonArray = [];
      for (var i = 1; i < classes.length; i++) {
        var kv = classes[i].trim().split("=");
        if (kv.length < 2) continue;
        var newCls = {
          type_name: kv[0].trim(),
          type_id: kv[1].trim()
        };
        jsonArray.push(newCls);
      }
    }
    var result = {
      class: []
    };
    if (jsonArray != null) {
      for (var _i = 0; _i < jsonArray.length; _i++) {
        var jObj = jsonArray[_i];
        var typeName = jObj.type_name;
        if (isBan(typeName)) continue;
        var typeId = jObj.type_id;
        var _newCls = {
          type_id: typeId,
          type_name: typeName
        };
        var typeExtend = jObj.type_extend;
        if (filter) {
          var _filterStr = getFilterTypes(url, typeExtend);
          var filters = _filterStr.split("\n");
          var filterArr = [];
          for (var k = url ? 1 : 0; k < filters.length; k++) {
            var l = filters[k].trim();
            if (!l) continue;
            var oneLine = l.split("+");
            var type = oneLine[0].trim();
            var typeN = type;
            if (type.includes("筛选")) {
              type = type.replace(/筛选/g, "");
              if (type === "class") typeN = "类型";else if (type === "area") typeN = "地区";else if (type === "lang") typeN = "语言";else if (type === "year") typeN = "年份";
            }
            var jOne = {
              key: type,
              name: typeN,
              value: []
            };
            for (var j = 1; j < oneLine.length; j++) {
              var _kv = oneLine[j].trim();
              var sp = _kv.indexOf("=");
              if (sp === -1) {
                if (isBan(_kv)) continue;
                jOne.value.push({
                  n: _kv,
                  v: _kv
                });
              } else {
                var n = _kv.substring(0, sp);
                if (isBan(n)) continue;
                jOne.value.push({
                  n: n.trim(),
                  v: _kv.substring(sp + 1).trim()
                });
              }
            }
            filterArr.push(jOne);
          }
          if (!result.hasOwnProperty("filters")) {
            result.filters = {};
          }
          result.filters[typeId] = filterArr;
        }
        result.class.push(_newCls);
      }
    }
    return JSON.stringify(result);
  } catch (e) {}
  return "";
}
function homeVod() {
  try {
    var apiUrl = host;
    var url = getRecommendUrl(apiUrl);
    var isTV = false;
    if (!url) {
      url = getCateFilterUrlPrefix(apiUrl) + "movie&page=1&area=&type=&start=";
      isTV = true;
    }
    var json = request(url, getHeaders(url));
    var obj = JSON.parse(json);
    var videos = [];
    if (isTV) {
      var jsonArray = obj.data;
      for (var i = 0; i < jsonArray.length; i++) {
        var vObj = jsonArray[i];
        var v = {
          vod_id: vObj.nextlink,
          vod_name: vObj.title,
          vod_pic: vObj.pic,
          vod_remarks: vObj.state
        };
        videos.push(v);
      }
    } else {
      var arrays = [];
      findJsonArray(obj, "vlist", arrays);
      if (arrays.length === 0) {
        findJsonArray(obj, "vod_list", arrays);
      }
      var ids = [];
      for (var _i2 = 0, _arrays = arrays; _i2 < _arrays.length; _i2++) {
        var _jsonArray = _arrays[_i2];
        for (var _i3 = 0; _i3 < _jsonArray.length; _i3++) {
          var _vObj = _jsonArray[_i3];
          var vid = _vObj.vod_id;
          if (ids.includes(vid)) continue;
          ids.push(vid);
          var _v = {
            vod_id: vid,
            vod_name: _vObj.vod_name,
            vod_pic: _vObj.vod_pic,
            vod_remarks: _vObj.vod_remarks
          };
          videos.push(_v);
        }
      }
    }
    var result = {
      list: videos
    };
    return JSON.stringify(result);
  } catch (e) {}
  return "";
}
function category(tid, pg, filter, extend) {
  try {
    var _extend$class, _extend$area, _extend$lang, _extend$year, _extend$排序;
    var apiUrl = host;
    var url = getCateFilterUrlPrefix(apiUrl) + tid + getCateFilterUrlSuffix(apiUrl);
    url = url.replace(/#PN#/g, pg);
    url = url.replace(/筛选class/g, (_extend$class = extend === null || extend === void 0 ? void 0 : extend.class) !== null && _extend$class !== void 0 ? _extend$class : "");
    url = url.replace(/筛选area/g, (_extend$area = extend === null || extend === void 0 ? void 0 : extend.area) !== null && _extend$area !== void 0 ? _extend$area : "");
    url = url.replace(/筛选lang/g, (_extend$lang = extend === null || extend === void 0 ? void 0 : extend.lang) !== null && _extend$lang !== void 0 ? _extend$lang : "");
    url = url.replace(/筛选year/g, (_extend$year = extend === null || extend === void 0 ? void 0 : extend.year) !== null && _extend$year !== void 0 ? _extend$year : "");
    url = url.replace(/排序/g, (_extend$排序 = extend === null || extend === void 0 ? void 0 : extend.排序) !== null && _extend$排序 !== void 0 ? _extend$排序 : "");
    var json = request(url, getHeaders(url));
    var obj = JSON.parse(json);
    var totalPg = Infinity;
    try {
      if (obj.totalpage !== undefined && typeof obj.totalpage === "number") {
        totalPg = obj.totalpage;
      } else if (obj.pagecount !== undefined && typeof obj.pagecount === "number") {
        totalPg = obj.pagecount;
      } else if (obj.data !== undefined && _typeof(obj.data) === "object" && obj.data.total !== undefined && typeof obj.data.total === "number" && obj.data.limit !== undefined && typeof obj.data.limit === "number") {
        var limit = obj.data.limit;
        var total = obj.data.total;
        totalPg = total % limit === 0 ? total / limit : Math.floor(total / limit) + 1;
      }
    } catch (e) {}
    var jsonArray = obj.list !== undefined ? obj.list : obj.data !== undefined && obj.data.list !== undefined ? obj.data.list : obj.data;
    var videos = [];
    if (jsonArray !== undefined) {
      for (var i = 0; i < jsonArray.length; i++) {
        var vObj = jsonArray[i];
        var v = {
          vod_id: vObj.vod_id !== undefined ? vObj.vod_id : vObj.nextlink,
          vod_name: vObj.vod_name !== undefined ? vObj.vod_name : vObj.title,
          vod_pic: vObj.vod_pic !== undefined ? vObj.vod_pic : vObj.pic,
          vod_remarks: vObj.vod_remarks !== undefined ? vObj.vod_remarks : vObj.state
        };
        videos.push(v);
      }
    }
    var result = {
      page: pg,
      pagecount: totalPg,
      limit: 90,
      total: Infinity,
      list: videos
    };
    return JSON.stringify(result);
  } catch (e) {
    SpiderDebug.log(e);
  }
  return "";
}
function detail(ids) {
  try {
    var apiUrl = host;
    var url = getPlayUrlPrefix(apiUrl) + ids;
    var json = request(url, getHeaders(url));
    var obj = JSON.parse(json);
    var result = {
      list: []
    };
    var vod = {};
    genPlayList(apiUrl, obj, json, vod, ids);
    result.list.push(vod);
    return JSON.stringify(result);
  } catch (e) {}
  return "";
}
var parseUrlMap = new Map();
function genPlayList(URL, object, json, vod, vid) {
  var playUrls = [];
  var playFlags = [];
  if (URL.includes("lfytyl.com")) {
    var data = object.data;
    vod.vod_id = data.vod_id || vid;
    vod.vod_name = data.vod_name;
    vod.vod_pic = data.vod_pic;
    vod.type_name = data.vod_class || "";
    vod.vod_year = data.vod_year || "";
    vod.vod_area = data.vod_area || "";
    vod.vod_remarks = data.vod_remarks || "";
    vod.vod_actor = data.vod_actor || "";
    vod.vod_director = data.vod_director || "";
    vod.vod_content = data.vod_content || "";
    vod.vod_play_from = data.vod_play_from;
    vod.vod_play_url = data.vod_play_url;
    return;
  }
  if (URL.includes("api.php/app")) {
    var _data = object.data;
    vod.vod_id = _data.vod_id || vid;
    vod.vod_name = _data.vod_name;
    vod.vod_pic = _data.vod_pic;
    vod.type_name = _data.vod_class || "";
    vod.vod_year = _data.vod_year || "";
    vod.vod_area = _data.vod_area || "";
    vod.vod_remarks = _data.vod_remarks || "";
    vod.vod_actor = _data.vod_actor || "";
    vod.vod_director = _data.vod_director || "";
    vod.vod_content = _data.vod_content || "";
    var vodUrlWithPlayer = _data.vod_url_with_player;
    for (var i = 0; i < vodUrlWithPlayer.length; i++) {
      var from = vodUrlWithPlayer[i];
      var flag = from.code.trim();
      if (flag === "") flag = from.name.trim();
      playFlags.push(flag);
      playUrls.push(from.url);
      var purl = from.parse_api;
      var parseUrls = parseUrlMap.get(flag) || [];
      if (purl && !parseUrls.includes(purl)) {
        parseUrls.push(purl);
      }
      parseUrlMap.set(flag, parseUrls);
    }
  } else if (URL.includes("xgapp")) {
    var _data2 = object.data.vod_info;
    vod.vod_id = _data2.vod_id || vid;
    vod.vod_name = _data2.vod_name;
    vod.vod_pic = _data2.vod_pic;
    vod.type_name = _data2.vod_class || "";
    vod.vod_year = _data2.vod_year || "";
    vod.vod_area = _data2.vod_area || "";
    vod.vod_remarks = _data2.vod_remarks || "";
    vod.vod_actor = _data2.vod_actor || "";
    vod.vod_director = _data2.vod_director || "";
    vod.vod_content = _data2.vod_content || "";
    var _vodUrlWithPlayer = _data2.vod_url_with_player;
    for (var _i4 = 0; _i4 < _vodUrlWithPlayer.length; _i4++) {
      var _from = _vodUrlWithPlayer[_i4];
      var _flag = _from.code.trim();
      if (_flag === "") _flag = _from.name.trim();
      playFlags.push(_flag);
      playUrls.push(_from.url);
      var _purl = _from.parse_api.trim();
      var _parseUrls = parseUrlMap.get(_flag) || [];
      if (_purl && !_parseUrls.includes(_purl)) {
        _parseUrls.push(_purl);
      }
      parseUrlMap.set(_flag, _parseUrls);
    }
  } else if (URL.includes(".vod")) {
    var _data3 = object.data;
    vod.vod_id = _data3.vod_id || vid;
    vod.vod_name = _data3.vod_name;
    vod.vod_pic = _data3.vod_pic;
    vod.type_name = _data3.vod_class || "";
    vod.vod_year = _data3.vod_year || "";
    vod.vod_area = _data3.vod_area || "";
    vod.vod_remarks = _data3.vod_remarks || "";
    vod.vod_actor = _data3.vod_actor || "";
    vod.vod_director = _data3.vod_director || "";
    vod.vod_content = _data3.vod_content || "";
    var _vodUrlWithPlayer2 = _data3.vod_play_list;
    for (var _i5 = 0; _i5 < _vodUrlWithPlayer2.length; _i5++) {
      var _from2 = _vodUrlWithPlayer2[_i5];
      var _flag2 = _from2.player_info.from.trim();
      if (_flag2 === "") _flag2 = _from2.player_info.show.trim();
      playFlags.push(_flag2);
      playUrls.push(_from2.url);
      try {
        var parses = [];
        var parse1 = _from2.player_info.parse.split(",");
        var parse2 = _from2.player_info.parse2.split(",");
        parses.push.apply(parses, _toConsumableArray(parse1).concat(_toConsumableArray(parse2)));
        var _parseUrls2 = parseUrlMap.get(_flag2) || [];
        for (var _i6 = 0, _parses = parses; _i6 < _parses.length; _i6++) {
          var _purl2 = _parses[_i6];
          if (_purl2.includes("http")) {
            var match = _purl2.match(parsePattern1);
            if (match) {
              _parseUrls2.push(match[0]);
            }
          } else if (_purl2.includes("//")) {
            var _match = _purl2.match(parsePattern1);
            if (_match) {
              _parseUrls2.push("http:" + _match[0]);
            }
          } else {
            var urlMatch = URL.match(parsePattern2);
            if (urlMatch) {
              var _match2 = URL.match(parsePattern1);
              if (_match2) {
                _parseUrls2.push(urlMatch[0] + _match2[0]);
              }
            }
          }
          if (_purl2.includes("..")) _purl2.replace(/\.\./g, ".").trim(), _readOnlyError("purl");
          if (_purl2 && !_parseUrls2.includes(_purl2)) {
            _parseUrls2.push(_purl2);
          }
        }
        parseUrlMap.set(_flag2, _parseUrls2);
      } catch (e) {}
    }
  } else if (URLPattern1.matcher(URL).find()) {
    // Same implementation as the previous cases
  }
  vod.vod_play_from = playFlags.join("$$$");
  vod.vod_play_url = playUrls.join("$$$");
}
function play(flag, id, vipFlags) {
  try {
    // let parseUrls = parseUrlMap.get(flag);
    var parseUrls = siteJx[flag]; // custom sitejx
    if (!parseUrls) {
      if (siteJx.hasOwnProperty('*')) {
        // all jx
        parseUrls = siteJx['*'];
      } else {
        parseUrls = [];
      }
    }
    if (parseUrls.length > 0) {
      var result = getFinalVideo(flag, parseUrls, id);
      if (result !== null) {
        return JSON.stringify(result);
      }
    }
    if (isVideo(id)) {
      var _result = {
        parse: 0,
        playUrl: "",
        url: id
      };
      return JSON.stringify(_result);
    } else {
      var _result2 = {
        parse: 1,
        jx: "1",
        url: id
      };
      return JSON.stringify(_result2);
    }
  } catch (e) {
    // Handle any error here
  }
  return "";
}
function search(key, quick) {
  try {
    var apiUrl = host;
    var url = getSearchUrl(apiUrl, encodeURIComponent(key));
    var json = request(url, getHeaders(url));
    var obj = JSON.parse(json);
    var jsonArray = null;
    var videos = [];
    if (_instanceof(obj.list, Array)) {
      jsonArray = obj.list;
    } else if (_instanceof(obj.data, Object) && _instanceof(obj.data.list, Array)) {
      jsonArray = obj.data.list;
    } else if (_instanceof(obj.data, Array)) {
      jsonArray = obj.data;
    }
    if (jsonArray !== null) {
      var _iterator = _createForOfIteratorHelper(jsonArray),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var vObj = _step.value;
          if (vObj.vod_id) {
            var v = {
              vod_id: vObj.vod_id,
              vod_name: vObj.vod_name,
              vod_pic: vObj.vod_pic,
              vod_remarks: vObj.vod_remarks
            };
            videos.push(v);
          } else {
            var _v2 = {
              vod_id: vObj.nextlink,
              vod_name: vObj.title,
              vod_pic: vObj.pic,
              vod_remarks: vObj.state
            };
            videos.push(_v2);
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    var result = {
      list: videos
    };
    return JSON.stringify(result);
  } catch (error) {}
  return "";
}
function getFinalVideo(flag, parseUrls, url) {
  var htmlPlayUrl = "";
  var _iterator2 = _createForOfIteratorHelper(parseUrls),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var parseUrl = _step2.value;
      if (parseUrl === "" || parseUrl === "null") {
        continue;
      }
      var playUrl = parseUrl + url;
      var content = request(playUrl, null, 10000); // 10秒请求，能更好过滤webjx
      var tryJson = null;
      try {
        tryJson = jsonParse(url, content);
      } catch (error) {}
      if (tryJson !== null && tryJson.hasOwnProperty("url") && tryJson.hasOwnProperty("header")) {
        tryJson.header = JSON.stringify(tryJson.header);
        return tryJson;
      }
      if (content.includes("<html")) {
        var sniffer = false;
        var _iterator3 = _createForOfIteratorHelper(htmlVideoKeyMatch),
          _step3;
        try {
          for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
            var p = _step3.value;
            if (p.test(content)) {
              sniffer = true;
              break;
            }
          }
        } catch (err) {
          _iterator3.e(err);
        } finally {
          _iterator3.f();
        }
        if (sniffer) {
          htmlPlayUrl = parseUrl;
        }
      }
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  if (htmlPlayUrl !== "") {
    // 不支持sniffer
    var result = {
      parse: 0,
      playUrl: "",
      url: url
    };
    return JSON.stringify(result);
  }
  return null;
}
function jsonParse(input, json) {
  try {
    // 处理解析接口返回的报文，如果返回的报文中包含header信息，就加到返回值中
    var jsonPlayData = JSON.parse(json);
    // 处理293的解析结果url在data字段的解析
    if (jsonPlayData.hasOwnProperty("data") && _typeof(jsonPlayData.data) === "object" && !jsonPlayData.hasOwnProperty("url")) {
      jsonPlayData = jsonPlayData.data;
    }
    var url = jsonPlayData.url;
    if (url.startsWith("//")) {
      url = "https:" + url;
    }
    if (!url.trim().startsWith("http")) {
      return null;
    }
    if (url === input) {
      if (isVip(url) || !isVideoFormat(url)) {
        return null;
      }
    }
    if (isBlackVodUrl(input, url)) {
      return null;
    }
    var headers = {};
    if (jsonPlayData.hasOwnProperty("header")) {
      headers = jsonPlayData.header;
    } else if (jsonPlayData.hasOwnProperty("Header")) {
      headers = jsonPlayData.Header;
    } else if (jsonPlayData.hasOwnProperty("headers")) {
      headers = jsonPlayData.headers;
    } else if (jsonPlayData.hasOwnProperty("Headers")) {
      headers = jsonPlayData.Headers;
    }
    var ua = "";
    if (jsonPlayData.hasOwnProperty("user-agent")) {
      ua = jsonPlayData["user-agent"];
    } else if (jsonPlayData.hasOwnProperty("User-Agent")) {
      ua = jsonPlayData["User-Agent"];
    }
    if (ua.trim().length > 0) {
      headers["User-Agent"] = " " + ua;
    }
    var referer = "";
    if (jsonPlayData.hasOwnProperty("referer")) {
      referer = jsonPlayData.referer;
    } else if (jsonPlayData.hasOwnProperty("Referer")) {
      referer = jsonPlayData.Referer;
    }
    if (referer.trim().length > 0) {
      headers["Referer"] = " " + referer;
    }
    headers = fixJsonVodHeader(headers, input, url);
    var taskResult = {
      header: headers,
      url: url,
      parse: "0"
    };
    return taskResult;
  } catch (error) {}
  return null;
}
function isVip(url) {
  try {
    var _isVip = false;
    var _host = new URL(url).hostname;
    var vipWebsites = ["iqiyi.com", "v.qq.com", "youku.com", "le.com", "tudou.com", "mgtv.com", "sohu.com", "acfun.cn", "bilibili.com", "baofeng.com", "pptv.com"];
    for (var b = 0; b < vipWebsites.length; b++) {
      if (_host.includes(vipWebsites[b])) {
        if (vipWebsites[b] === "iqiyi.com") {
          // 爱奇艺需要特殊处理
          if (url.includes("iqiyi.com/a_") || url.includes("iqiyi.com/w_") || url.includes("iqiyi.com/v_")) {
            _isVip = true;
            break;
          }
        } else {
          _isVip = true;
          break;
        }
      }
    }
    return _isVip;
  } catch (e) {}
  return false;
}
function isBlackVodUrl(input, url) {
  return url.includes("973973.xyz") || url.includes(".fit:");
}
function fixJsonVodHeader(headers, input, url) {
  if (headers === null) {
    headers = {};
  }
  if (input.includes("www.mgtv.com")) {
    headers["Referer"] = " ";
    headers["User-Agent"] = " Mozilla/5.0";
  } else if (url.includes("titan.mgtv")) {
    headers["Referer"] = " ";
    headers["User-Agent"] = " Mozilla/5.0";
  } else if (input.includes("bilibili")) {
    headers["Referer"] = " https://www.bilibili.com/";
    headers["User-Agent"] = " " + Misc.UaWinChrome;
  }
  return headers;
}
var snifferMatch = /http((?!http).){26,}?\.(m3u8|mp4|flv|avi|mkv|rm|wmv|mpg)\?.*|http((?!http).){26,}\.(m3u8|mp4|flv|avi|mkv|rm|wmv|mpg)|http((?!http).){26,}\/m3u8\?pt=m3u8.*|http((?!http).)*?default\.ixigua\.com\/.*|http((?!http).)*?cdn-tos[^\?]*|http((?!http).)*?\/obj\/tos[^\?]*|http.*?\/player\/m3u8play\.php\?url=.*|http.*?\/player\/.*?[pP]lay\.php\?url=.*|http.*?\/playlist\/m3u8\/\?vid=.*|http.*?\.php\?type=m3u8&.*|http.*?\/download.aspx\?.*|http.*?\/api\/up_api.php\?.*|https.*?\.66yk\.cn.*|http((?!http).)*?netease\.com\/file\/.*/;
function isVideoFormat(url) {
  if (snifferMatch.test(url)) {
    return !url.includes("cdn-tos") || !url.includes(".js");
  }
  return false;
}
function isVideo(url) {
  if (!url.includes(".mp4") || !url.includes(".m3u8")) {
    return true;
  }
  return false;
}
function UA(url) {
  if (url.includes(".vod")) {
    return "okhttp/4.1.0";
  }
}
function getCateUrl(URL) {
  if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    return URL + "nav?token=";
  } else if (URL.includes(".vod")) {
    return URL + "/types";
  } else {
    return "";
  }
}
function getPlayUrlPrefix(URL) {
  if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    return URL + "video_detail?id=";
  } else if (URL.includes(".vod")) {
    return URL + "/detail?vod_id=";
  } else {
    return "";
  }
}
function getRecommendUrl(URL) {
  if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    return URL + "index_video?token=";
  } else if (URL.includes(".vod")) {
    return URL + "/vodPhbAll";
  } else {
    return "";
  }
}
function getFilterTypes(URL, typeExtend) {
  var str = "";
  if (typeExtend !== null) {
    for (var key in typeExtend) {
      if (key === "class" || key === "area" || key === "lang" || key === "year") {
        try {
          str += "筛选" + key + "+全部=+" + typeExtend[key].replace(/,/g, "+") + "\n";
        } catch (e) {}
      }
    }
  }
  if (URL.includes(".vod")) {
    str += "\n" + "排序+全部=+最新=time+最热=hits+评分=score";
  } else if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    // Do nothing, leave the string as it is.
  } else {
    str = "分类+全部=+电影=movie+连续剧=tvplay+综艺=tvshow+动漫=comic+4K=movie_4k+体育=tiyu\n筛选class+全部=+喜剧+爱情+恐怖+动作+科幻+剧情+战争+警匪+犯罪+动画+奇幻+武侠+冒险+枪战+恐怖+悬疑+惊悚+经典+青春+文艺+微电影+古装+历史+运动+农村+惊悚+惊悚+伦理+情色+福利+三级+儿童+网络电影\n筛选area+全部=+大陆+香港+台湾+美国+英国+法国+日本+韩国+德国+泰国+印度+西班牙+加拿大+其他\n筛选year+全部=+2023+2022+2021+2020+2019+2018+2017+2016+2015+2014+2013+2012+2011+2010+2009+2008+2007+2006+2005+2004+2003+2002+2001+2000";
  }
  return str;
}
function getCateFilterUrlSuffix(URL) {
  if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    return "&class=筛选class&area=筛选area&lang=筛选lang&year=筛选year&limit=18&pg=#PN#";
  } else if (URL.includes(".vod")) {
    return "&class=筛选class&area=筛选area&lang=筛选lang&year=筛选year&by=排序&limit=18&page=#PN#";
  } else {
    return "&page=#PN#&area=筛选area&type=筛选class&start=筛选year";
  }
}
function getCateFilterUrlPrefix(URL) {
  if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    return URL + "video?tid=";
  } else if (URL.includes(".vod")) {
    return URL + "?type=";
  } else {
    return URL + "?ac=list&class=";
  }
}
function isBan(key) {
  return key === "伦理" || key === "情色" || key === "福利";
}
function getSearchUrl(URL, KEY) {
  if (URL.includes(".vod")) {
    return URL + "?wd=" + KEY + "&page=";
  } else if (URL.includes("api.php/app") || URL.includes("xgapp")) {
    return URL + "search?text=" + KEY + "&pg=";
  } else if (urlPattern1.test(URL)) {
    return URL + "?ac=list&zm=" + KEY + "&page=";
  }
  return "";
}
function findJsonArray(obj, match, result) {
  Object.keys(obj).forEach(function (k) {
    try {
      var o = obj[k];
      if (k === match && Array.isArray(o)) {
        result.push(o);
      }
      if (_typeof(o) === "object" && o !== null) {
        if (Array.isArray(o)) {
          o.forEach(function (item) {
            if (_typeof(item) === "object" && item !== null) {
              findJsonArray(item, match, result);
            }
          });
        } else {
          findJsonArray(o, match, result);
        }
      }
    } catch (e) {}
  });
}
function jsonArr2Str(array) {
  var strings = [];
  for (var i = 0; i < array.length; i++) {
    try {
      strings.push(array[i]);
    } catch (e) {}
  }
  return strings.join(",");
}
function getHeaders(URL) {
  var headers = {};
  headers["User-Agent"] = UA(URL);
  return headers;
}
function isJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}
function __jsEvalReturn() {
  return {
    init: init,
    home: home,
    homeVod: homeVod,
    category: category,
    detail: detail,
    play: play,
    search: search
  };
}
