require("./util.js");
require("./ali.js");
require("./quark.js");
require("./alist_share.js");

var __panDetailError = ""

function initPan() {
  const alist_share_switch = getBoolStorage("alist_share_switch") || !isNewAPP()
  if (alist_share_switch) {
    initAlistShare();
  }
  initAli();
  initQuark();
}

function panDetailContent(vod, ids) {
    ids = ids.filter((item, index, array) => array.indexOf(item) === index);
  const froms = [];
  const urls = [];
  for (const shareUrl of ids) {
      if (froms.length >= 2) {
          break;
      }
      const shareData = getAliShareData(shareUrl);
      const alist_share_switch = getBoolStorage("alist_share_switch") || !isNewAPP()
      if (shareData) {
        if (canAlistInit() && alist_share_switch) {
          const vods = alistDetailContent(vod, shareData)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }else{
          const vods = aliDetailContent(vod, shareData)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }
      }else {
        const shareData = getQuarkShareData(shareUrl);
        if (shareData) {
          const vods = quarkDetailContent(vod, shareData)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }
      }
  }
  if (ids.length > 0) {
    froms.push("分享链接");
    var items = [];
    for (let shareUrl of ids) {
      if (shareUrl.length) {
        var name = shareUrl;
        if (name.includes("aliyundrive.com") || name.includes("alipan.com")) {
          name = "阿里云盘"
        }else if (name.includes("quark.cn")) {
          name = "夸克网盘"
        }else if (name.includes("xunlei.com")) {
          name = "迅雷云盘"
        }else if (name.includes("baidu.com")) {
          name = "百度网盘"
        }
        items.push(name + "$" + shareUrl);
      }
    }
    urls.push(items);
  }
  return {
    tabs: froms,
    lists: urls,
    error: __panDetailError
  };
}

function panPlay(id, flag) {
  if (flag.startsWith('Ali-')) {
    return aliPlay(id, flag);
  } else if (flag.startsWith('Quark-')) {
    return quarkPlay(id, flag)
  } else {
    return alistPlay(id, flag)
  }
}
