var _mod = require("./mod.js");
var __drives = {};
var __authorization = "";
var __accessToken = "";
var __refresh_token = "";
var __driveName = "";
var request_timeout = 5e3;
var __alist_tvbox_server = ""
var __my_share_path = "/我的分享"
var __detailError = ""
var refresh = false;
let patternAli = /www.aliyundrive.com\/s\/([^\/]+)(\/folder\/([^\/]+))?/
function initAlistShare() {
  if (__driveName.length > 0) {
    return;
  }
  var data;
  var alist_data_url = "http://localhost:8689/file/alist_share.json";
  let res = http.get(alist_data_url);
  let text = res.text();
  data = res.json();
  if (text.length > 0 && !data) {
    __detailError = "alist_share.json文件JSON解析失败,可尝试更换文本编辑器后重试";
    return;
  }
  if (!data || !data.hasOwnProperty('alist_server')) {
      __detailError = "没有找到alist_share.json文件";
      return;
  }
  if (data && data.hasOwnProperty('alist_token')) {
    __authorization = data.alist_token;
//      refresh = __authorization.length > 0;
  }
  if (data && data.hasOwnProperty('my_share_path')) {
    __my_share_path = data.my_share_path;
  }
  if (data && data.hasOwnProperty('refresh_token')) {
    __refresh_token = data.refresh_token;
  }
  if (data && data.hasOwnProperty('alist_tvbox_server') && data.hasOwnProperty('alist_tvbox_username') && data.hasOwnProperty('alist_tvbox_password')) {
    __alist_tvbox_server = data.alist_tvbox_server;
    var alist_tvbox_username = data.alist_tvbox_username;
    var alist_tvbox_password = data.alist_tvbox_password;
    var login_url = __alist_tvbox_server + "/api/accounts/login";
    var params = { username: alist_tvbox_username, password: alist_tvbox_password, rememberMe: true, authenticated: false };
    var tvboxData = http.post(login_url, { data: params }).json();
    if (tvboxData && tvboxData.hasOwnProperty('token')) {
      __accessToken = tvboxData.token;
      __driveName = "Alist";
      __detailError = "";
    }else{
        __detailError = "tvbox token获取失败，请检查tvbox server或username或password是否配置正确";
    }
  }else{
      __detailError = "未能读取tvbox server或username或password";
  }
  var drive = {
    name: __driveName,
    server: data.alist_server,
    params: data.params,
    startPage: data.tempPage
  };
  var drives = [drive];
  print(drives);
  drives.forEach(function (item) {
    var _path_param = [];
    if (item.params) {
      _path_param = Object.keys(item.params);
      _path_param.sort(function (a, b) {
        return a.length - b.length;
      });
    }
    __drives[item.name] = {
      name: item.name,
      server: item.server.endsWith("/") ? item.server.rstrip("/") : item.server,
      startPage: item.startPage || "/",
      params: item.params || {},
      _path_param: _path_param,
      settings: {},
      api: {},
      getParams: function getParams(path) {
        var key = this._path_param.find(function (x) {
          return path.startsWith(x);
        });
        return Object.assign({}, this.params[key], {
          path: path,
          refresh: refresh
        });
      },
      getPath: function getPath(path) {
        try {
          var res = httpAlist(this.server + this.api.path, {
            data: this.getParams(path)
          });
          if (!res) {
            __detailError = "获取文件列表错误，请检查alist server或alist token是否配置正确";
            return null;
          }else if (res.hasOwnProperty("message") && res.message != "success" && (!res.hasOwnProperty("data") || !res.data)) {
            __detailError = res.message;
            if(__detailError.includes("object not found")) {
              __detailError = __detailError + "资源可能失效了"
            }
            return null;
          }
          return res.data.content;
        } catch (e) {
          __detailError = "获取文件列表错误,可能资源失效了";
          return null;
        }
      },
      addShare: function addShare(params) {
        var res = httpAlist(this.server + this.api.addShare, {
          data: params
        });
        return res;
      },
      getFile: function getFile(path) {
        var raw_url = this.server + "/d" + path;
        raw_url = encodeURI(raw_url);
        let raw = this.getFileRaw(path);
        if (raw.hasOwnProperty('sign') || raw.sign.length) {
          raw_url = raw_url + "?sign=" + raw.sign
        }
        return {
        raw_url: raw_url,
        data: raw
        };
      },
      getFileRaw: function getFile(path) {
        var _post_data = {
          path: path
        };
        var res = httpAlist(this.server + this.api.file, {
          data: _post_data
        });
        return res.data;
        // var url = res.data.raw_url
        // return {
        //   raw_url: url
        // }
      },
      videoPreview: function videoPreview(path) {
          var _post_data = {
            path: path,
            method: "video_preview"
          };
          var res = http.post(this.server + this.api.videoPreview, {
            data: _post_data
          }).json();
          var liveTranscodingTaskList = res.data.video_preview_play_info.live_transcoding_task_list;
          let highestQualityURL = "";
          for (let task of liveTranscodingTaskList) {
            if (task.template_id === "QHD") {
                highestQualityURL = task.url;
                break;
            } else if (task.template_id === "FHD") {
                highestQualityURL = task.url;
            } else if (task.template_id === "HD" && highestQualityURL === "") {
                highestQualityURL = task.url;
            } else if (task.template_id === "SD" && highestQualityURL === "") {
                highestQualityURL = task.url;
            }
          }
          var url = highestQualityURL === "" ? (liveTranscodingTaskList[liveTranscodingTaskList.length - 1].url) : highestQualityURL
          // var decodedUri = decodeURI(url);
          return {
            raw_url: url
          };
     },
      isFolder: function isFolder(data) {
        return data.type === 1;
      },
      isVideo: function isVideo(data) {
        var ext = /\.(iso|m3u8|mp4|mov|avi|wmv|flv|mkv|webm|3gp|mpg|mpeg|swf|m4v|f4v|ogv|vob|ts|mts|m2ts|divx|rm|m4a|wav|wma)$/;
        if (ext.test(data.name) && data.type === 0) {
            return true;
        }
        return data.type === 2 || data.type === 3;
      },
      is_subt: function is_subt(data) {
        if (data.type === 1) {
          return false;
        }
        var ext = /\.(srt|ass|scc|stl|ttml)$/;
        return ext.test(data.name);
      },
      getPic: function getPic(data) {
        var pic = data.thumb;
        return pic || (this.isFolder(data) ? "http://img1.3png.com/281e284a670865a71d91515866552b5f172b.png" : "");
      },
      getTime: function getTime(data, isStandard) {
        isStandard = isStandard || false;
        try {
          var tTime = data.updated_at || data.time_str || data.modified || "";
          var date = "";
          if (tTime) {
            tTime = tTime.split("T");
            date = tTime[0];
            if (isStandard) {
              date = date.replace(/-/g, "/");
            }
            tTime = tTime[1].split(/Z|\./);
            date += " " + tTime[0];
          }
          return date;
        } catch (e) {
          return "";
        }
      }
    };
  });
}

function httpAlist(url, options) {
  options.headers = Object.assign({
    'Authorization': __authorization
  }, options.headers);
  var res = http.post(url, options).json();
  return res;
}

function httpAlistTVBox(url, options) {
  options.headers = Object.assign({
    'X-Access-Token': __accessToken
  }, options.headers);
  var res = http.post(url, options).json();
  return res;
}
function get_drives() {
  var _drives$name = __drives[__driveName],
    settings = _drives$name.settings,
    api = _drives$name.api,
    server = _drives$name.server;
  api.path = "/api/fs/list";
  api.file = "/api/fs/get";
  api.addShare = "/api/admin/storage/create";
  api.videoPreview = "/api/fs/other";
  return __drives[__driveName];
}

function addAlistShare(path, shareId, folderId) {
  let drive = get_drives()
  if (!folderId || !folderId.length) {
    folderId = "root"
  }
  var params = {
    "addition": "{\"refresh_token\":\"" + __refresh_token + "\",\"share_id\":\"" + shareId + "\",\"share_pwd\":\"\",\"root_folder_id\":\"" + folderId + "\",\"order_by\":\"\",\"order_direction\":\"\"}",
    "cache_expiration": 30,
    "down_proxy_url": "",
    "driver": "AliyundriveShare",
    "enable_sign": false,
    "extract_folder": "",
    "mount_path": path,
    "order": 0,
    "remark": "",
    "web_proxy": false,
    "webdav_policy": "302_redirect"
  };
  var res = drive.addShare(params);
}

function addAlistTVBoxShare(path, shareId, folderId) {
  var add_share_url = __alist_tvbox_server + "/api/shares/";
  var params = {
    "id": "",
    "path": path,
    "shareId": shareId,
    "folderId": folderId,
    "password": "",
    "cookie": "",
    "type": 0
  };
  var res = httpAlistTVBox(add_share_url, {
    data: params
  });
  if (res && res.hasOwnProperty('detail')) {
    if (!res.detail.includes("Unique index or primary key violation")) {
      __detailError = res.detail;
    }else{
      __detailError = "";
    }
  }else{
    __detailError = "";
  }
}

function formatPlayUrl(src, name) {
  if (src.trim() == name.trim()) {
      return name;
  }
  return name
      .trim()
      .replaceAll(src, '')
      .replace(/<|>|《|》/g, '')
      .replace(/\$|#/g, ' ')
      .trim();
}

function canAlistInit() {
  if (__alist_tvbox_server.length && __accessToken.length && __driveName.length > 0) {
    return true;
  }
  return false;
}

function alistDetailContent(vod, shareData) {
  var shareId = shareData.shareId, folderId = shareData.folderId;
  var vodName = vod.vod_name || ""
  vodName = vodName.replace(/\s+/g, '');
  if (!hasChinese(vodName)) {
    vodName = "【分享】" + vodName
  }
  var folderPath = ""
  if (folderId.length > 0) {
    folderPath = "-" + folderId
  }
  let path = __my_share_path + "/" + vodName + "-" + shareId + folderPath

  var playFrom = [],
  lists = [];
  if (shareId.length && __alist_tvbox_server.length && __accessToken.length) {
    addAlistTVBoxShare(path, shareId, folderId);
  // }else if (__refresh_token.length){
  //   addAlistShare(path, shareId, folderId);
  }else{
    playFrom.push("ERROR");
    lists.push([__detailError + "$"]);
    return {
      tabs: playFrom,
      lists: lists,
      error: __detailError
    };
  }
  
  var dirPlayFrom = [];
  var episodes = [];
  findVideos(path, dirPlayFrom, episodes, null, 0)
  for (var i in dirPlayFrom) {
      if (dirPlayFrom.hasOwnProperty(i)) {
          playFrom.push(dirPlayFrom[i]);
          lists.push(episodes[i]);
      }
  }
  if (episodes.length == 0) {
    playFrom.push("ERROR");
    lists.push([__detailError + "$"]);
  }
  let vodPlay = {
    tabs: playFrom,
    lists: lists,
    error: __detailError
  };
  return vodPlay;
}

function findVideos(dir, playFrom, episodes, parentName, deepness) {
  let drive = get_drives()
  var files = drive.getPath(dir);
  if (!files || !files.length) {
    return
  }
  let hasVideo = false;
  let episodeList = [];

  var subList = [];
  for (let file of files) {
    if (drive.is_subt(file)) {
      subList.push(file.name);
    }
  }
  for (let file of files) {
    let filePath = dir + '/' + file.name;
    if (drive.isFolder(file)) {
      if (playFrom.length >= 5 || deepness > 3) {
        continue;
      }
      findVideos(filePath, playFrom, episodes, file.name, deepness+1);
    } else {
      if (drive.isVideo(file)) {
        if (file.size < 10 * 1024 * 1024 && (file.name.includes("4k") || file.name.includes("4K"))) {
          continue;
        }
        var vod_size = get_size(file.size);
        var content = filePath

        if (subList.length) {
          var lh = 0;
          var sub;
          subList.forEach(function (s) {
            var l = levenshteinDistance(s, file.name);
            l += (s.includes("chs") ? 100 : 0)
            if (l > 60 && l > lh) {
              sub = s;
              lh = l;
            }
          });
          if (sub) {
            let filePath = dir + '/' + sub;
            content += "@@@" + filePath;
          }
        }
        let name = episodeNameTrim(file.name);
        episodeList.push(name + " " + vod_size + "$" + content);
        hasVideo = true;
      }
    }
  }
  if (hasVideo) {
    playFrom.push((parentName || "默认"));
    episodes.push(episodeList);
  }
}

function alistPlay(id, flag) {
  let drive = get_drives();
  var urls = id.split("@@@");
  var data = drive.getFile(urls[0]);
  var videoUrl = data.raw_url;
  var vod = {
    parse: 0,
    jx: 0,
    url: videoUrl
  };
  var fileData = data.data;
  if (fileData.raw_url.includes("x-oss") || fileData.thumb.includes("x-oss")) {
    let urlDeeplink = "vidplay://x-callback-url/play?source=AliyunDrive&name=" + fileData.name + "&size=" + fileData.size;
    let urlDeeplinkPreview = urlDeeplink + "&preview=1";
    vod["urls"] = [
      { "name": "直链", "url": videoUrl },
      { "name": "我的阿里云盘-原画", "url": urlDeeplink },
      {"name": "我的阿里云盘-预览", "url": urlDeeplinkPreview}
    ];
  }
  if (urls.length >= 2) {
    var path = urls[0].substring(0, urls[0].lastIndexOf("/") + 1);
    vod.subt = drive.getFile(path + urls[1]).raw_url;
  }
  return vod;
}
