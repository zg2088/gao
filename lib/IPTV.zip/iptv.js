function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
String.prototype.rstrip = function (chars) {
  var regex = new RegExp(chars + "$");
  return this.replace(regex, "");
};
var request_timeout = 5000;
var RKEY = 'live2cms'; // 源的唯一标识
var VERSION = 'live2cms 20230619';
var UA = 'Mozilla/5.0'; //默认请求ua
var __ext = {
  data_dict: {}
};
var tips = "\n\u9053\u957F\u76F4\u64AD\u8F6C\u70B9\u64ADjs-\u5F53\u524D\u7248\u672C".concat(VERSION);
var def_pic = 'https://avatars.githubusercontent.com/u/97389433?s=120&v=4';
const local = new Map();
/**
 * 存在数据库配置表里, key字段对应值value,没有就新增,有就更新,调用此方法会清除key对应的内存缓存
 * @param k 键
 * @param v 值
 */
function setItem(k, v) {
  local.set(RKEY, k, v);
  console.log("\u89C4\u5219".concat(RKEY, "\u8BBE\u7F6E").concat(k, " => ").concat(v));
}

/**
 *  获取数据库配置表对应的key字段的value，没有这个key就返回value默认传参.需要有缓存,第一次获取后会存在内存里
 * @param k 键
 * @param v 值
 * @returns {*}
 */
function getItem(k, v) {
  return local.get(RKEY, k) || v;
}

/**
 *  删除数据库key对应的一条数据,并清除此key对应的内存缓存
 * @param k
 */
function clearItem(k) {
  local.delete(RKEY, k);
}
var showMode = getItem('showMode', 'groups'); // groups按组分类显示 all全部一条线路展示
var groupDict = JSON.parse(getItem('groupDict', '{}')); // 搜索分组字典

/**
 * 打印日志
 * @param any 任意变量
 */
function print(any) {
  any = any || '';
  if (_typeof(any) == 'object' && Object.keys(any).length > 0) {
    try {
      any = JSON.stringify(any);
      console.log(any);
    } catch (e) {
      // console.log('print:'+e.message);
      console.log(_typeof(any) + ':' + any.length);
    }
  } else if (_typeof(any) == 'object' && Object.keys(any).length < 1) {
    console.log('null object');
  } else {
    console.log(any);
  }
}

var http = function http(url) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (options.method === "POST" && options.data) {
    options.body = JSON.stringify(options.data);
    options.headers = Object.assign({
      "content-type": "application/json"
    }, options.headers);
    options.headers = Object.assign({
    }, options.headers);
  }
  options.timeout = request_timeout;
  try {
    var res = req(url, options);
    res.json = function () {
      return res && res.content ? JSON.parse(res.content) : null;
    };
    res.text = function () {
      return res && res.content ? res.content : "";
    };
    return res;
  } catch (e) {
    return {
      json: function json() {
        return null;
      },
      text: function text() {
        return "";
      }
    };
  }
};
["get", "post"].forEach(function (method) {
  http[method] = function (url) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return http(url, Object.assign(options, {
      method: method.toUpperCase()
    }));
  };
});

/*** js自封装的方法 ***/

/**
 * 获取链接的host(带http协议的完整链接)
 * @param url 任意一个正常完整的Url,自动提取根
 * @returns {string}
 */
function getHome(url) {
  if (!url) {
    return '';
  }
  var tmp = url.split('//');
  url = tmp[0] + '//' + tmp[1].split('/')[0];
  try {
    url = decodeURIComponent(url);
  } catch (e) {}
  return url;
}

/**
 * m3u直播格式转一般直播格式
 * @param m3u
 * @returns {string}
 */
function convertM3uToNormal(m3u) {
  try {
    var lines = m3u.split('\n');
    var result = '';
    var TV = '';
    // let flag='#genre#';
    var flag = '#m3u#';
    var currentGroupTitle = '';
    lines.forEach(function (line) {
      if (line.startsWith('#EXTINF:')) {
        var groupTitle = line.split('"')[1].trim();
        TV = line.split('"')[2].substring(1);
        if (currentGroupTitle !== groupTitle) {
          currentGroupTitle = groupTitle;
          result += "\n".concat(currentGroupTitle, ",").concat(flag, "\n");
        }
      } else if (line.startsWith('http')) {
        var splitLine = line.split(',');
        result += "".concat(TV, ",").concat(splitLine[0], "\n");
      }
    });
    return result.trim();
  } catch (e) {
    print("m3u\u76F4\u64AD\u8F6C\u666E\u901A\u76F4\u64AD\u53D1\u751F\u9519\u8BEF:".concat(e.message));
    return m3u;
  }
}

/**
 * 线路归类
 * @param arr
 * @returns {*[][]}
 */
function merge(arr) {
  var parse = arguments[1] ? arguments[1] : '';
  var p = [];
  if (parse !== '' && typeof parse == "function") {
    p = arr.map(parse);
  }
  var createEmptyArrays = function createEmptyArrays(length) {
    return Array.from({
      length: length
    }, function () {
      return [];
    });
  };
  var lists = createEmptyArrays(arr.length);
  var sl = createEmptyArrays(arr.length);
  (p.length ? p : arr).forEach(function (k, index) {
    var i = 0;
    while (sl[i].includes(k)) {
      i = i + 1;
    }
    sl[i].push(k);
    lists[i].push(arr[index]);
  });
  lists = lists.filter(function (x) {
    return x.some(function (k) {
      return k.length;
    });
  });
  return lists;
}

/**
 * 线路归类/小棉袄算法
 * @param arr 数组
 * @param parse 解析式
 * @returns {[[*]]}
 */
function splitArray(arr, parse) {
  parse = parse && typeof parse == 'function' ? parse : '';
  var result = [[arr[0]]];
  for (var i = 1; i < arr.length; i++) {
    var index = -1;
    for (var j = 0; j < result.length; j++) {
      if (parse && result[j].map(parse).includes(parse(arr[i]))) {
        index = j;
      } else if (!parse && result[j].includes(arr[i])) {
        index = j;
      }
    }
    if (index >= result.length - 1) {
      result.push([]);
      result[result.length - 1].push(arr[i]);
    } else {
      result[index + 1].push(arr[i]);
    }
  }
  return result;
}

/**
 * 搜索结果生成分组字典
 * @param arr
 * @param parse x=>x.split(',')[0]
 * @returns {{}}
 */
function gen_group_dict(arr, parse) {
  var dict = {};
  arr.forEach(function (it) {
    var k = it.split(',')[0];
    if (parse && typeof parse === 'function') {
      k = parse(k);
    }
    if (!dict[k]) {
      dict[k] = [it];
    } else {
      dict[k].push(it);
    }
  });
  return dict;
}
var http = function http(url) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (options.method === 'POST' && options.data) {
    options.body = JSON.stringify(options.data);
    options.headers = Object.assign({
      'content-type': 'application/json'
    }, options.headers);
  }
  options.timeout = request_timeout;
  if (!options.headers) {
    options.headers = {};
  }
  var keys = Object.keys(options.headers).map(function (it) {
    return it.toLowerCase();
  });
  if (!keys.includes('referer')) {
    options.headers['Referer'] = getHome(url);
  }
  if (!keys.includes('user-agent')) {
    options.headers['User-Agent'] = UA;
  }
  console.log(JSON.stringify(options.headers));
  try {
    var res = req(url, options);
    // if(options.headers['Authorization']){
    //     console.log(res.content);
    // }
    res.json = function () {
      return res && res.content ? JSON.parse(res.content) : null;
    };
    res.text = function () {
      return res && res.content ? res.content : '';
    };
    return res;
  } catch (e) {
    return {
      json: function json() {
        return null;
      },
      text: function text() {
        return '';
      }
    };
  }
};
["get", "post"].forEach(function (method) {
  http[method] = function (url) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return http(url, Object.assign(options, {
      method: method.toUpperCase()
    }));
  };
});
function init(ext) {
  console.log("当前版本号:" + VERSION);
  var data;
  if (_typeof(ext) == 'object') {
    data = ext;
    print('live ext:object');
  } else if (typeof ext == 'string') {
    if (ext.startsWith('http')) {
      var ext_paramas = ext.split(';');
      var data_url = ext_paramas[0];
      print(data_url);
      data = http.get(data_url).json();
    }else{
        var extDic = JSON.parse(ext);
        var urls = extDic.url.split("$");
        var mydata = [];
        urls.forEach(function (url) {
            var name = urls.length > 1 ? "IPTV" : ("IPTV" + (mydata.length+1))
            var data = {
            name: "IPTV",
            url:url
            }
            mydata.push(data)
        });
        data = mydata
    }
  }
  print(data);
  __ext.data = data;
  print('init执行完毕');
}
function home(filter) {
  var classes = __ext.data.map(function (it) {
    return {
      type_id: it.url,
      type_name: it.name
    };
  });
  print("----home----");
  var filter_dict = {};
  var filters = [{
    'key': 'show',
    'name': '播放展示',
    'value': [{
      'n': '多线路分组',
      'v': 'groups'
    }, {
      'n': '单线路',
      'v': 'all'
    }]
  }];
  classes.forEach(function (it) {
    filter_dict[it.type_id] = filters;
  });
  print(classes);
  return JSON.stringify({
    'class': classes,
    'filters': filter_dict
  });
}
function homeVod(params) {
  var _get_url = __ext.data[0].url;
  var html;
  if (__ext.data_dict[_get_url]) {
    html = __ext.data_dict[_get_url];
  } else {
    html = http.get(_get_url).text();
    if (/#EXTM3U/.test(html)) {
      html = convertM3uToNormal(html);
    }
    __ext.data_dict[_get_url] = html;
  }
  // let arr = html.match(/.*?,#[\s\S].*?#/g);
  var arr = html.match(/.*?[,，]#[\s\S].*?#/g); // 可能存在中文逗号
  var _list = [];
  try {
    arr.forEach(function (it) {
      var vname = it.split(/[,，]/)[0];
      var vtab = it.match(/#(.*?)#/)[0];
      _list.push({
        vod_name: vname,
        vod_id: _get_url + '$' + vname,
        vod_pic: def_pic,
        vod_remarks: vtab
      });
    });
  } catch (e) {
    print('Live2cms获取首页推荐发送错误:' + e.message);
  }
  return JSON.stringify({
    'list': _list
  });
}
function category(tid, pg, filter, extend) {
  var fl = filter ? extend : {};
  if (fl.show) {
    showMode = fl.show;
    setItem('showMode', showMode);
  }
  if (parseInt(pg) > 1) {
    return JSON.stringify({
      'list': []
    });
  }
  var _get_url = tid;
  var html;
  if (__ext.data_dict[_get_url]) {
    html = __ext.data_dict[_get_url];
  } else {
    html = http.get(_get_url).text();
    if (/#EXTM3U/.test(html)) {
      html = convertM3uToNormal(html);
    }
    __ext.data_dict[_get_url] = html;
  }
  // let arr = html.match(/.*?[,，]#[\s\S].*?#/g);
  var arr = html.match(/.*?[,，]#[\s\S].*?#/g); // 可能存在中文逗号
  var _list = [];
  try {
    arr.forEach(function (it) {
      var vname = it.split(/[,，]/)[0];
      var vtab = it.match(/#(.*?)#/)[0];
      _list.push({
        // vod_name:it.split(',')[0],
        vod_name: vname,
        vod_id: _get_url + '$' + vname,
        vod_pic: def_pic,
        vod_remarks: vtab
      });
    });
  } catch (e) {
    print('Live2cms获取一级分类页发生错误:' + e.message);
  }
  return JSON.stringify({
    'page': 1,
    'pagecount': 1,
    'limit': _list.length,
    'total': _list.length,
    'list': _list
  });
}
function detail(tid) {
  // ⛵  港•澳•台
  var _get_url = tid.split('$')[0];
  var _tab = tid.split('$')[1];
  if (tid.includes('#search#')) {
    var _vod_name = _tab.replace('#search#', '');
    var _vod_play_from = '来自搜索';
    _vod_play_from += ":".concat(_get_url);

    // let vod_play_url = vod_name+'$'+_get_url;
    // print(vod_play_url);

    var _vod_play_url = groupDict[_get_url].map(function (x) {
      return x.replace(',', '$');
    }).join('#');
    return JSON.stringify({
      list: [{
        vod_id: tid,
        vod_name: '搜索:' + _vod_name,
        type_name: "直播列表",
        vod_pic: def_pic,
        vod_content: tid,
        vod_play_from: _vod_play_from,
        vod_play_url: _vod_play_url,
        vod_director: tips,
        vod_remarks: "\u9053\u957F\u76F4\u64AD\u8F6C\u70B9\u64ADjs-\u5F53\u524D\u7248\u672C".concat(VERSION)
      }]
    });
  }
  var html;
  if (__ext.data_dict[_get_url]) {
    html = __ext.data_dict[_get_url];
  } else {
    html = http.get(_get_url).text();
    if (/#EXTM3U/.test(html)) {
      html = convertM3uToNormal(html);
    }
    __ext.data_dict[_get_url] = html;
  }
  // let a = new RegExp(`.*?${_tab},#[\\s\\S].*?#`);
  var a = new RegExp(".*?".concat(_tab.replace('(', '\\(').replace(')', '\\)'), "[,\uFF0C]#[\\s\\S].*?#"));
  var b = html.match(a)[0];
  var c = html.split(b)[1];
  if (c.match(/.*?[,，]#[\s\S].*?#/)) {
    var d = c.match(/.*?[,，]#[\s\S].*?#/)[0];
    c = c.split(d)[0];
  }
  var arr = c.trim().split('\n');
  var _list = [];
  arr.forEach(function (it) {
    if (it.trim()) {
      var t = it.trim().split(',')[0];
      var u = it.trim().split(',')[1];
      _list.push(t + '$' + u);
    }
  });
  var vod_name = __ext.data.find(function (x) {
    return x.url === _get_url;
  }).name;
  var vod_play_url;
  var vod_play_from;
  if (showMode === 'groups') {
    var groups = splitArray(_list, function (x) {
      return x.split('$')[0];
    });
    var tabs = [];
    for (var i = 0; i < groups.length; i++) {
      if (i === 0) {
        tabs.push(vod_name + '1');
      } else {
        tabs.push(" ".concat(i + 1, " "));
      }
    }
    vod_play_url = groups.map(function (it) {
      return it.join('#');
    }).join('$$$');
    vod_play_from = tabs.join('$$$');
  } else {
    vod_play_url = _list.join('#');
    vod_play_from = vod_name;
  }
  var vod = {
    vod_id: tid,
    vod_name: vod_name + '|' + _tab,
    type_name: "直播列表",
    vod_pic: def_pic,
    vod_content: tid,
    vod_play_from: vod_play_from,
    vod_play_url: vod_play_url,
    vod_director: tips,
    vod_remarks: "\u9053\u957F\u76F4\u64AD\u8F6C\u70B9\u64ADjs-\u5F53\u524D\u7248\u672C".concat(VERSION)
  };
  return JSON.stringify({
    list: [vod]
  });
}
function play(flag, id, flags) {
  var vod = {
    'parse': 0,
//      'parse': /m3u8/.test(id) ? 0 : 1,
    'playUrl': '',
    'url': id
  };
  print(vod);
  return JSON.stringify(vod);
}
function search(wd, quick) {
  var _get_url = __ext.data[0].url;
  var html;
  if (__ext.data_dict[_get_url]) {
    html = __ext.data_dict[_get_url];
  } else {
    html = http.get(_get_url).text();
    if (/#EXTM3U/.test(html)) {
      html = convertM3uToNormal(html);
    }
    __ext.data_dict[_get_url] = html;
  }
  var str = '';
  Object.keys(__ext.data_dict).forEach(function () {
    str += __ext.data_dict[_get_url];
  });
  var links = str.split('\n').filter(function (it) {
    return it.trim() && it.includes(',') && it.split(',')[1].trim().startsWith('http');
  });
  links = links.map(function (it) {
    return it.trim();
  });
  var plays = Array.from(new Set(links));
  print('搜索关键词:' + wd);
  print('过滤前:' + plays.length);
  plays = plays.filter(function (it) {
    return it.includes(wd);
  });
  print('过滤后:' + plays.length);
  print(plays);
  var new_group = gen_group_dict(plays);
  groupDict = Object.assign(groupDict, new_group);
  // 搜索分组结果存至本地方便二级调用
  setItem('groupDict', JSON.stringify(groupDict));
  var _list = [];

  // plays.forEach((it)=>{
  //     _list.push({
  //         'vod_name':it.split(',')[0],
  //         'vod_id':it.split(',')[1].trim()+'$'+it.split(',')[0].trim()+'#search#',
  //         'vod_pic':def_pic,
  //     })
  // });

  Object.keys(groupDict).forEach(function (it) {
    _list.push({
      'vod_name': it,
      'vod_id': it + '$' + wd + '#search#',
      'vod_pic': def_pic
    });
  });
  return JSON.stringify({
    'list': _list
  });
}

// 导出函数对象
var _default = {
  init: init,
  home: home,
  homeVod: homeVod,
  category: category,
  detail: detail,
  play: play,
  search: search
};
